#!/bin/bash
<<COMMENTBLOCK
VAR="yes, we have txt string here"
#instead of
#if echo "$VAR" | grep -q txt  # if [ [ $VAR = *txt*  ] ]
#etc

#try:
if grep -q "txt" <<<"$VAR"
then
    echo "$VAR contains the substring sequence \"txt\""
fi

#thanks
COMMENTBLOCK

String="This is a string of words"

read -r -a Words <<< "$String"
# The -a option to "read" input and 
#+assigns the resulting values to successive members of an array

for word in Words
do
    echo ${word[@]}
done

