first_var=12
second_var=014

echo $first_var
echo $second_var
echo "$first_var"
echo "$second_var"

typeset -i first_var
typeset -i second_var

if [ "$first_var" == "$second_var" ]
then
    echo "string comparision: equal"
else
    echo "string comparision: not equal"
fi

first_var=12
second_var=014

echo $first_var
echo $second_var
echo "$first_var"
echo "$second_var"

typeset -i first_var
typeset -i second_var

echo $first_var
echo $second_var
echo "$first_var"
echo "$second_var"

if [ "$first_var" -eq "$second_var" ]
then
    echo "arithmetic comparision: equal"
else
    echo "arithmetic comparision: not equal"
fi

if [ "$first_var" == "$second_var" ]
then
    echo "string comparision: equal"
else
    echo "string comparision: not equal"
fi

directory=$(pwd)
echo $directory
echo $first_var
echo $second_var
echo "$first_var"
echo "$second_var"

if [ "$first_var" -eq "$second_var" ]
then
    echo "arithmetic comparision: equal"
else
    echo "arithmetic comparision: not equal"
fi

if [ "$first_var" == "$second_var" ]
then
    echo "string comparision: equal"
else
    echo "string comparision: not equal"
fi

directory=$(pwd)
echo $directory
