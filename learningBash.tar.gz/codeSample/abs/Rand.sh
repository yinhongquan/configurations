#!/bin/bash

# $RANDOM returns a different random integer at each invocation
# Nominal range: 0 ~ 32767 (signed 16-bit integer)

declare -i MAXCOUNT=10
declare -i count=1

echo
echo "$MAXCOUNT random numbers:"
echo "-------------------------"
while [ "$count" -le "$MAXCOUNT" ]
do
    number=$RANDOM
    echo $number
    count+=1
done
echo "-------------------------"

# Note variables spread over multiple lines
Suites="Clubs
Diamonds
Hearts
Spades
"

Denominations="2
3
4
5
6
7
8
9
10
Jack
Queen
King
Ace
"
suite=($Suites)         #Read into array variables
denomination=($Denominations)

num_suite=${#suite[*]}
num_denomination=${#denomination[*]}

echo -n "${denomination[$((RANDOM%num_denomination))]}"
echo ${suite[$((RANDOM%num_suite))]}
