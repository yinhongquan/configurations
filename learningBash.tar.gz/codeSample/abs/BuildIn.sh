#!/bin/bash
# wf.sh: Crude word frequency analysis on a text file.
# This is a more efficient version of another script.

# Check fo rinput file on command-line
ARGS=1
E_BADARGS=85
E_NOFILE=86

if [ $# -ne "$ARGS" ]; then
    echo "Usage: basename $0 filename"
    exit $E_BADARGS
fi

if [ ! -f "$1" ]; then
    echo "File \'${1}\' doesn't exist"
    exit $E_NOFILE
fi

sed -e 's/\.//g' -e 's/\,//g' -e 's/\;//g' -e 's/ /\
/g' "${1}" | tr 'A-Z' 'a-z' | sort| uniq -c | sort -nr

exit 0

