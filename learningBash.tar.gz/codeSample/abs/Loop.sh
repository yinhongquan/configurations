#!/bin/bash

FILES="/usr/sbin/accept
/usr/sbin/pwck
/usr/sbin/chroot
/usr/bin/fakefile
/sbin/badblocks
/sbin/ypbind"

echo

for file in $FILES
do
    if [ ! -e "$file" ] # check if file exists
    then
        echo "$file does not exist"; echo;
        continue;
    fi

    ls -l $file | awk  '{ print $9 "         file size: " $5 }' # Print 2 fields
#    whatis 'basename $file'
    echo
done

echo "---------------------------------------------"
filename="*"

for file in $filename
do
    echo "Contents of $file"
    echo "---"
#    cat "$file"
    echo
done

for word in $( strings "/etc/hosts" | grep "1" )
do
    echo $word
done

echo "---------------------------------------------"
PASSWORD_FILE=/etc/passwd
n=1     # User number

for name in $(awk 'BEGIN{FS=":"}{print $1}' < "$PASSWORD_FILE" )
# Get input from password file /etc/password, and print the first
#+field separated by ":"
do
    echo "USER #$n = $name"
    let "n += 1"
done

echo "---------------------------------------------"
directory=/usr/bin/
fstring="Free Software Foundation" # See which files come from the FSF

for file in $( find $directory -type f -name '*' | sort )
do
    strings -f $file | grep "$fstring" | sed -e "s%$directory%%"
done

echo "---------------------------------------------"

exit 0
