#!/bin/bash

args=$#
echo "There are \"$args\" arguments passed from console"
echo "another way to know argument# is ${#}"

echo "The name of this script is \"$0\"."
echo "The name of this script is \"'basename $0'\""
echo "--------------------------"
echo "all parameters are : "$*""
echo "all parameters are : "$@""

arch=$(uname -m)
echo $arch

unassigned=

if [ -z $unassigned ]
then
    echo "\$unassigned is NULL"
fi

echo "\$unassigned=$unassigned"
let "unassigned += 5"
echo "$unassigned"

param4=${4:-$0}
echo $param4
