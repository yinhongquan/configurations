#!/bin/bash

randomBetween() {
    # generates a positive or negative random number
    #+between $min and $max
    #+and divisible by $divisibleBy
    # Gives a "reasonably random" distribution of return values

    function syntax(){
        echo "Syntax"
    }

    local min=${1:-0}
    local max=${2:-32767}
    local divisibleBy=${3:-1}
    #default values assigned, in case parameters not passed to function
    local x
    local spread

    #let's make sure the divisibleBy is positive
    [ ${divisibleBy} -lt 0 ] && divisible=$((0-divisibleBy))

    #sanity check
    if [ $# -gt 3 ] || [ ${divisibleBy} -eq 0 ] || [ ${min} -eq ${max} ]; then
        syntax
        return 1
    fi

    # see if the min and max are reversed
    if [ ${min} -gt ${max} ]; then
        #swap them
        x=${min}
        min=${max}
        max=${x}
    fi

    # If min is itself not evenly divisible by $divisibleBy,
    #+then fix the min to be within range.
    if [ $((min/divisibleBy*divisibleBy)) -ne ${min} ]; then
        if [ ${min} -lt 0 ]; then
            min=$((min/divisibleBy*divisibleBy))
        else
            min=$(((min/divisibleBy + 1)*divisibleBy))
        fi
    fi

    #                                                       
    # Now, do the real work
    # Note that to get a proper distribution for the end points
    #+the range of random values has to be allowed to go between
    #+0 and abs(max-min)+divisibleBy, not just abs(max-min) + 1
    #                                                       
    spread=$((max-min))
    [ ${spread} -lt 0 ] && spread=$((0 - spread))
    let spread+=divisibleBy
    randomBetweenAnswer=$((((RANDOM%spread)/divisibleBy)*divisibleBy+min))
    return ${randomBetweenAnswer}
}

#randomBetween 1 100 10

function tuneArgument() {
    local value=$1
    local divisibleBy=$2
    local upBound=$3

    echo ${value} ${divisibleBy} ${upBound}
    if [ ${upBound} -eq 0 ]; then
        if [ $((value/divisibleBy*divisibleBy)) -ne ${value} ]; then
            echo "intermediate value " $((value/divisibleBy*divisibleBy))
            if [ ${value} -lt 0 ]; then
                value=$((value/divisibleBy*divisibleBy))
         else
                value=$(((value/divisibleBy + 1)*divisibleBy))
            fi
        fi
     else
        if [ $((value/divisibleBy*divisibleBy)) -ne ${value} ]; then
            if [ ${value} -lt 0 ]; then
                value=$(((value/divisibleBy - 1)*divisibleBy))
         else
                value=$((value/divisibleBy*divisibleBy))
            fi
        fi
     fi

     echo "result is ${value}"
     return ${value}
}

min=-14
max=20
divisibleBy=3
# Generate an array of expected answers and check to make sure we
#+get at least one of each answer if we loop long enough

declare -a answer
minimum=${min}
maximum=${max}

# tune minimum for divisibleBy
tuneArgument ${minimum} ${divisibleBy} 0
minimum=$?
echo ${minimum}
tuneArgument ${maximum} ${divisibleBy} 1
maximum=$?
echo ${maximum}

# Tune minimum value manually, for as tuneArgument returns a bad value
#+don't know why yet
minimum=-12

disp=$((0 - minimum))
for ((i=${minimum}; i<=${maximum}; i+=divisibleBy)); do
    answer[i+disp]=0
done

# Now loop a large number of times to see what we get
loopIt=1000

for ((i=0; i<${loopIt}; ++i)); do
    randomBetween ${max} ${min} ${divisibleBy}

    # Report an error if an answer is unexpected
    [ ${randomBetweenAnswer} -lt ${min} -o ${randomBetweenAnswer} -gt ${max} ] && echo MIN or MAX error - ${randomBetweenAnswer}!
done
