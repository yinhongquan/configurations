#!/bin/bash
cd /Applications/RealVNC/VNC\ Viewer.app/Contents/MacOS
./vncviewer AutoSelect=0 FullColor=1 192.168.55.80:5901

