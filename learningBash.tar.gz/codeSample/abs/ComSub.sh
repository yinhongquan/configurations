#!/bin/bash

script_name="basename $0"
echo "The name of the script file is $script_name."

echo "-------------------------------------"
textfile_listing='ls *.sh'
echo $textfile_listing

echo "-------------------------------------"
textfile_listing2=$(ls *.sh)
echo $textfile_listing2

PIDS=$(pidof sh $0)
P_array={ $PIDS }

echo $PIDS
