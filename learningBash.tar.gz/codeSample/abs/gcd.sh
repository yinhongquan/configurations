#!/bin/bash
# gcd.sh: greatest common divisor
#         use Euclid's algorithm

# The "greatest common divisor" (gcd) of two integers
#+ is the largest integer that will divide both, leaving no remainder

# Euclid's algorithm uses successive division
#   In each pass,
#       dividend<-- divisor
#       divisor<-- remainder
#+  until remainder = 0.
#   The gcd = dividend, on the final pass
#
# For an excellent discussion of Euclid's algorithm, see Jim Loy's site

# -------------------------------------------------------
# Argument check
ARGS=2
E_BADARGS=85

if [ $# -ne "$ARGS" ]; then
    echo "Usage: 'basename $0' first-number second-number"
    exit $E_BADARGS
fi

typeset -i param1
typeset -i param2
param1=$1
param2=$2

# -------------------------------------------------------

function gcd()
{
    local dividend=$1
    local divisor=$2
    if [ "$dividend" -gt "$divisor" ]; then
        dividend=$2
        divisor=$1
    fi

    local remainder=1

    until [ "$remainder" -eq 0 ]
    do # $remainder must be initialized previously
        let "remainder = $dividend % $divisor"
        dividend=$divisor
        divisor=$remainder
    done

    return $dividend
}

function swap()
{
    local swapParam=$1
    $1=$2
    $2=$swapParam
    return 0
}

$(gcd $param1 $param2)
dividend=$?
echo; echo "GCD of $1 and $2 = $dividend"; echo

let "dividend <<=1"; echo $dividend
let "dividend <<=2"; echo $dividend
let "dividend >>=1"; echo $dividend
let "dividend >>=2"; echo $dividend

declare -f swap

exit 0
