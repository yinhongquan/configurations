#!/bin/bash
# str-test.sh: test null strings and unquoted strings
#+but not strings and sealing wax, not to mention cabbages and potatos

#Using if [ ... ]

# if a string has not been initialized, it has no defined value.
# this state is called "null", not the same as zero

if [ -n $string1 ] #string1 has not been declared or initialized
then
    echo "String \"string1\" is not null"
else
    echo "String \"string1\" is null" #expected result
fi

echo #add a new line for vertical separation

if [ -n "$string1" ] #this time, $string1 is quoted
then
    echo "String \"string1\" is not null" #expected result
else
    echo "String \"string1\" is null"
fi

echo #add a new line for vertical separation
if [ $string1 ] # This time, $string1 stands naked
then
    echo "String \"string1\" is not null" #expected result
else
    echo "String \"string1\" is null"
fi

echo #add a new line for vertical separation

string1=initialized

if [ $string1 ] #Again, $string1 stands unquoted
then
    echo "String \"string1\" is not null" #expected result
else
    echo "String \"string1\" is null"
fi
echo $string1

string1="aaa"
if [ $string1 ]
then
    echo "String \"string1\" is not null" #expected result
else
    echo "String \"string1\" is null"
fi

