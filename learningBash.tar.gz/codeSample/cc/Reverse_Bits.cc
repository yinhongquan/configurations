typedef unsigned int uint;
uint swapBits(uint x, uint i, uint j) {
    uint lo = ((x >> i) & 1);
    uint hi = ((x >> j) & 1);

    if(lo ^ hi)  { //need to swap if different
        uint mask = (1 << i | 1 << j);
        x = x ^ mask;
    }

    return x;
}

uint reverseXor(uint x) {
    uint n = sizeof(x) * 8;
    for(int i = 0; i <= n/2; ++i) {
        swap(x, i, n - 1 - i);
    }

    return x;
}
