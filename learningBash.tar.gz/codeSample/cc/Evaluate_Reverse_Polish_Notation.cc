//evaluate reverse polish notation

class Solution {
    public:
        int evalRPN(vector<string>& tokens) {
            stack<int> st; //stores intermediate results
            int x, y;
            for(int i = 0; i < tokens.size(); ++i) {
                //check if it is a numbner or operator
                if(tokens[i][0] >= '0' && tokens[i][0] <= '9' || tokens[i].length() > 1) {
                    int j = 0;
                    if(tokens[i][0] == '-')
                        j++; //escape negative mark

                    x = 0;
                    while(j < tokens[i].length()) {
                        x = x*10 + tokens[i][j] - '0';
                        j++;
                    }

                    if(tokens[i][0] == '-')
                        x = -x;
                    st.push(x);
                }
                else {
                    //it is an operator
                    assert(st.size() >= 2);
                    if(st.size() < 2)
                        return 0;

                    x = st.top(); st.pop();
                    y = st.top(); st.pop();
                    if(tokens[i][0] == '+')
                        st.push(y + x);
                    else if(tokens[i][0] == '-')
                        st.push(y - x);
                    else if(tokens[i][0] == '*')
                        st.push(y * x);
                    else if(tokens[i][0] == '/' && x != 0)
                        st.push(y / x);
                    else{
                        assert(false);
                        return 0;
                    }
                }
            }

            return st.empty() ? 0 : st.top();
        }
};
