//reverse the notation of an integer
class Solution {
    public:
        int reverseInt(int x) {
            int nRet = 0;

            while(x != 0) {
                nRet = nRet * 10 + x%10;
                x = x/10
            }
        }
};
