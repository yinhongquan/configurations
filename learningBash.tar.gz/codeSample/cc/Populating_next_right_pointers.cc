//suppose we have a binary tree with each node declared as
//struct Node {
//  Node* leftChild;
//  Node* rightChild;
//  Node* nextRight;
//  };
//populate the nextRight points to each nodes's right siblings

struct Node {
    Node* leftChild;
    Node* rightChild;
    Node* nextRight;
};

class Solution {
    public:
        bool PopulateNextRight(Node* pRoot)
        {
            if(NULL == pRoot)
                return false;

            Node *pCurrent = pRoot, *pBefore = NULL, *pNext = NULL;
            while(pCurrent->leftChild) {
                pBefore = pCurrent;
                while (pBefore) {
                    if(pBefore->leftChild)
                        pBefore->leftChild->nextRight = pBefore->rightChild;
                    else
                        break;

                    if(pBefore->rightChild)
                        pBefore->rightChild->nextRight = pBefore->nextRight != NULL ? pBefore->nextRight->leftChild : NULL;

                    pBefore = pBefore->nextRight;
                }

                pCurrent = pCurrent->leftChild;
            }

            return true;
        }

        bool PopulateNextRightRecur(Node *pRoot) {
            if(NULL == pRoot)
                return false;

            Node *pBefore = pRoot;
            while (pBefore) {
                if(pBefore->leftChild)
                    pBefore->leftChild->nextRight = pBefore->rightChild;
                else
                    break;

                if(pBefore->rightChild)
                    pBefore->rightChild->nextRight = pBefore->nextRight != NULL ? pBefore->nextRight->leftChild : NULL;

                pBefore = pBefore->nextRight;
            }

            return PopulateNextRightRecur(pRoot->leftChild);
        }
};
